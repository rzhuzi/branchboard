(() => {
  // src/shared/blob.ts
  function bytesToHex(bytes) {
    return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  }
  async function sha256Hex(data) {
    const subtle = globalThis.crypto?.subtle;
    if (!subtle) throw new Error("\u5F53\u524D\u6D4F\u89C8\u5668\u4E0D\u652F\u6301\u56FE\u7247\u5185\u5BB9\u6307\u7EB9");
    const buffer = data instanceof Blob ? await data.arrayBuffer() : data;
    const digest = await subtle.digest("SHA-256", buffer);
    return bytesToHex(new Uint8Array(digest));
  }
  function dataUrlToBlob(dataUrl) {
    const comma = dataUrl.indexOf(",");
    if (!dataUrl.startsWith("data:") || comma < 0) {
      throw new Error("\u65E0\u6548\u7684\u56FE\u7247\u6570\u636E");
    }
    const header = dataUrl.slice(5, comma);
    const mime = header.split(";")[0] || "image/png";
    const payload = dataUrl.slice(comma + 1);
    if (header.includes(";base64")) {
      const binary = atob(payload);
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index);
      }
      return new Blob([bytes], { type: mime });
    }
    return new Blob([decodeURIComponent(payload)], { type: mime });
  }

  // src/shared/db.ts
  var V2_DB_NAME = "branchboard-v2";
  var DB_VERSION = 2;
  var DOCUMENTS_STORE = "documents";
  var ASSETS_STORE = "assets";
  var PENDING_STORE = "pending";
  var REGISTRY_STORE = "registry";
  var VIEWPORTS_STORE = "viewports";
  function requestToPromise(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  }
  function openV2Database() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(V2_DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(DOCUMENTS_STORE)) {
          database.createObjectStore(DOCUMENTS_STORE, { keyPath: "id" });
        }
        if (!database.objectStoreNames.contains(ASSETS_STORE)) {
          database.createObjectStore(ASSETS_STORE, { keyPath: "id" });
        }
        if (!database.objectStoreNames.contains(PENDING_STORE)) {
          database.createObjectStore(PENDING_STORE, { keyPath: "id" });
        }
        if (!database.objectStoreNames.contains(REGISTRY_STORE)) {
          database.createObjectStore(REGISTRY_STORE, { keyPath: "id" });
        }
        if (!database.objectStoreNames.contains(VIEWPORTS_STORE)) {
          database.createObjectStore(VIEWPORTS_STORE, { keyPath: "canvasId" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function putAsset(asset) {
    const database = await openV2Database();
    try {
      const transaction = database.transaction(ASSETS_STORE, "readwrite");
      transaction.objectStore(ASSETS_STORE).put(asset);
      await transactionDone(transaction);
    } finally {
      database.close();
    }
  }
  async function addPending(image) {
    const database = await openV2Database();
    try {
      const transaction = database.transaction(PENDING_STORE, "readwrite");
      transaction.objectStore(PENDING_STORE).put(image);
      await transactionDone(transaction);
    } finally {
      database.close();
    }
  }
  async function listPending() {
    const database = await openV2Database();
    try {
      const transaction = database.transaction(PENDING_STORE, "readonly");
      const images = await requestToPromise(
        transaction.objectStore(PENDING_STORE).getAll()
      );
      return images.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    } finally {
      database.close();
    }
  }

  // src/shared/messages.ts
  var MSG = {
    runPrompt: "branchboard:v2:run-prompt",
    cancelRun: "branchboard:v2:cancel-run",
    importUrl: "branchboard:v2:import-url",
    resultNotice: "branchboard:v2:result-notice",
    theme: "branchboard:v2:theme",
    minimize: "branchboard:v2:minimize",
    progress: "branchboard:v2:progress",
    forwardPaste: "branchboard:v2:forward-paste",
    storeImage: "branchboard:v2:store-image",
    clipboardWrite: "branchboard:v2:clipboard-write",
    offscreenWrite: "branchboard:v2:offscreen-write",
    pendingUpdated: "branchboard:v2:pending-updated",
    toggleCanvas: "branchboard:v2:toggle-canvas"
  };

  // src/background/main.ts
  var OFFSCREEN_DOCUMENT_PATH = "offscreen.html";
  var creatingOffscreenDocument = null;
  async function notifyPendingUpdated() {
    try {
      await chrome.runtime.sendMessage({ type: MSG.pendingUpdated });
    } catch {
    }
  }
  function finiteDimension(value) {
    const number = Number(value);
    return Number.isFinite(number) && number > 0 ? Math.round(number) : 1024;
  }
  async function storeImage(message) {
    const dataUrl = String(message.dataUrl || "");
    if (!dataUrl.startsWith("data:image/")) throw new Error("\u53EA\u652F\u6301\u56FE\u7247\u6570\u636E");
    if (dataUrl.length > 4e7) throw new Error("\u56FE\u7247\u592A\u5927\uFF0C\u65E0\u6CD5\u4FDD\u5B58");
    const canvasId = String(message.canvasId || "");
    const requestId = String(message.requestId || "");
    if (!canvasId || !requestId) throw new Error("\u7F3A\u5C11\u753B\u5E03\u6216\u4EFB\u52A1\u6807\u8BC6");
    const blob = dataUrlToBlob(dataUrl);
    const hash = /^[a-f0-9]{64}$/i.test(String(message.hash || "")) ? String(message.hash).toLowerCase() : await sha256Hex(blob);
    const existing = await listPending();
    if (existing.some(
      (image) => image.requestId === requestId && image.hash === hash
    )) {
      return { ok: true };
    }
    const width = finiteDimension(message.width);
    const height = finiteDimension(message.height);
    const createdAt = (/* @__PURE__ */ new Date()).toISOString();
    const name = String(message.name || "\u751F\u6210\u56FE\u7247");
    const assetId = crypto.randomUUID();
    await putAsset({
      id: assetId,
      blob,
      mime: blob.type || "image/png",
      width,
      height,
      createdAt,
      hash,
      name
    });
    await addPending({
      id: crypto.randomUUID(),
      assetId,
      requestId,
      canvasId,
      promptId: message.promptId ? String(message.promptId) : void 0,
      name,
      width,
      height,
      createdAt,
      hash,
      relation: message.relation,
      position: Number.isFinite(message.position?.x) && Number.isFinite(message.position?.y) ? { x: Number(message.position?.x), y: Number(message.position?.y) } : void 0
    });
    void notifyPendingUpdated();
    return { ok: true };
  }
  async function hasOffscreenDocument() {
    const offscreen = chrome.offscreen;
    if (typeof offscreen?.hasDocument === "function") {
      return offscreen.hasDocument();
    }
    if (typeof chrome.runtime.getContexts === "function") {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
        documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
      });
      return contexts.length > 0;
    }
    const clientsApi = self.clients;
    if (!clientsApi) return false;
    const matchedClients = await clientsApi.matchAll();
    const offscreenUrl = chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH);
    return matchedClients.some((client) => client.url === offscreenUrl);
  }
  async function ensureOffscreenDocument() {
    if (await hasOffscreenDocument()) return;
    if (!creatingOffscreenDocument) {
      creatingOffscreenDocument = chrome.offscreen.createDocument({
        url: OFFSCREEN_DOCUMENT_PATH,
        reasons: ["CLIPBOARD"],
        justification: "Copy Branchboard prompt text or image to the clipboard."
      });
    }
    try {
      await creatingOffscreenDocument;
    } finally {
      creatingOffscreenDocument = null;
    }
  }
  async function writeClipboard(message) {
    await ensureOffscreenDocument();
    const response = await chrome.runtime.sendMessage({
      target: "offscreen",
      type: MSG.offscreenWrite,
      format: message.format,
      text: message.text,
      dataUrl: message.dataUrl
    });
    if (!response?.ok) {
      throw new Error(response?.error || "\u5199\u5165\u526A\u8D34\u677F\u5931\u8D25");
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === MSG.storeImage) {
      void storeImage(message).then((result) => sendResponse(result)).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    if (message?.type === MSG.clipboardWrite) {
      void writeClipboard(message).then(() => sendResponse({ ok: true })).catch(
        (error) => sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
    return false;
  });
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.id) return;
    try {
      await chrome.tabs.sendMessage(tab.id, { type: MSG.toggleCanvas });
    } catch {
    }
  });
})();
