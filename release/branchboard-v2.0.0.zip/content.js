(() => {
  // src/shared/blob.ts
  function bytesToHex(bytes) {
    return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
  }
  async function sha256Hex(data) {
    const subtle = globalThis.crypto?.subtle;
    if (!subtle) throw new Error("\u5F53\u524D\u6D4F\u89C8\u5668\u4E0D\u652F\u6301\u56FE\u7247\u5185\u5BB9\u6307\u7EB9");
    const buffer = data instanceof Blob ? await data.arrayBuffer() : data;
    const digest = await subtle.digest("SHA-256", buffer);
    return bytesToHex(new Uint8Array(digest));
  }
  function uniqueByKey(items, keyOf) {
    const seen = /* @__PURE__ */ new Set();
    const unique = [];
    for (const item of items) {
      const key = keyOf(item);
      if (seen.has(key)) continue;
      seen.add(key);
      unique.push(item);
    }
    return unique;
  }
  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }
  function imageSizeFromBlob(blob) {
    if (typeof createImageBitmap === "function") {
      return createImageBitmap(blob).then((bitmap) => {
        const size = { width: bitmap.width, height: bitmap.height };
        bitmap.close();
        return size;
      }).catch(() => imageSizeWithElement(blob));
    }
    return imageSizeWithElement(blob);
  }
  function imageSizeWithElement(blob) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(blob);
      const image = new Image();
      image.onload = () => {
        URL.revokeObjectURL(url);
        resolve({ width: image.naturalWidth, height: image.naturalHeight });
      };
      image.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error("\u65E0\u6CD5\u8BFB\u53D6\u56FE\u7247\u5C3A\u5BF8"));
      };
      image.src = url;
    });
  }

  // src/shared/messages.ts
  var MSG = {
    runPrompt: "branchboard:v2:run-prompt",
    cancelRun: "branchboard:v2:cancel-run",
    importUrl: "branchboard:v2:import-url",
    resultNotice: "branchboard:v2:result-notice",
    theme: "branchboard:v2:theme",
    minimize: "branchboard:v2:minimize",
    progress: "branchboard:v2:progress",
    forwardPaste: "branchboard:v2:forward-paste",
    storeImage: "branchboard:v2:store-image",
    clipboardWrite: "branchboard:v2:clipboard-write",
    offscreenWrite: "branchboard:v2:offscreen-write",
    pendingUpdated: "branchboard:v2:pending-updated",
    toggleCanvas: "branchboard:v2:toggle-canvas"
  };

  // src/shared/settings.ts
  var SETTINGS_KEY = "branchboardV2Settings";
  function systemTheme() {
    try {
      return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
    } catch {
      return "dark";
    }
  }
  function hasChromeStorage() {
    return typeof chrome !== "undefined" && Boolean(chrome.storage?.local);
  }
  function normalizeSettings(value) {
    const theme = typeof value === "object" && value !== null && "theme" in value && value.theme === "light" ? "light" : typeof value === "object" && value !== null && "theme" in value && value.theme === "dark" ? "dark" : systemTheme();
    return { theme };
  }
  function listenSettings(callback) {
    if (hasChromeStorage()) {
      const listener2 = (changes, areaName) => {
        if (areaName !== "local" || !changes[SETTINGS_KEY]) return;
        callback(normalizeSettings(changes[SETTINGS_KEY].newValue));
      };
      chrome.storage.onChanged.addListener(listener2);
      return () => chrome.storage.onChanged.removeListener(listener2);
    }
    const listener = (event) => {
      if (event.key !== SETTINGS_KEY || !event.newValue) return;
      try {
        callback(normalizeSettings(JSON.parse(event.newValue)));
      } catch {
      }
    };
    window.addEventListener("storage", listener);
    return () => window.removeEventListener("storage", listener);
  }
  async function readShellTheme() {
    try {
      if (hasChromeStorage()) {
        const result = await chrome.storage.local.get(SETTINGS_KEY);
        return normalizeSettings(result[SETTINGS_KEY]).theme;
      }
      const stored = localStorage.getItem(SETTINGS_KEY);
      return stored ? normalizeSettings(JSON.parse(stored)).theme : systemTheme();
    } catch {
      return systemTheme();
    }
  }

  // src/content/dom.ts
  function wait(milliseconds) {
    return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  }
  function visible(element) {
    if (!element) return false;
    if (element instanceof HTMLElement && element.hidden) return false;
    return element.getClientRects().length > 0;
  }
  function findComposer() {
    const selectors = [
      "#prompt-textarea",
      "textarea[data-testid='prompt-textarea']",
      "form textarea",
      "[contenteditable='true'][data-testid='prompt-textarea']",
      "main form [contenteditable='true']",
      "main [contenteditable='true'][data-virtualkeyboard='true']"
    ];
    for (const selector of selectors) {
      const candidates = Array.from(document.querySelectorAll(selector));
      for (const element of candidates) {
        if (element instanceof HTMLTextAreaElement || element instanceof HTMLElement && element.isContentEditable) {
          if (visible(element)) return element;
        }
      }
    }
    return null;
  }
  function composerText(composer) {
    if (composer instanceof HTMLTextAreaElement) return composer.value;
    return (composer.innerText || composer.textContent || "").trim();
  }
  function fillComposer(composer, text) {
    composer.focus();
    if (composer instanceof HTMLTextAreaElement) {
      const setter = Object.getOwnPropertyDescriptor(
        HTMLTextAreaElement.prototype,
        "value"
      )?.set;
      if (setter) setter.call(composer, text);
      else composer.value = text;
      composer.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          inputType: "insertText",
          data: text
        })
      );
      composer.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(composer);
    selection?.removeAllRanges();
    selection?.addRange(range);
    const inserted = document.execCommand("insertText", false, text);
    if (!inserted) {
      composer.textContent = text;
      composer.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          inputType: "insertText",
          data: text
        })
      );
    }
  }
  function findSendButton() {
    const scope = findComposer()?.closest("form") || document;
    const selectors = [
      "button[data-testid='send-button']",
      "button[aria-label*='Send' i]",
      "button[aria-label*='\u53D1\u9001']"
    ];
    for (const selector of selectors) {
      const buttons = Array.from(scope.querySelectorAll(selector));
      for (const button of buttons) {
        if (button instanceof HTMLButtonElement && !button.disabled && !button.hidden && visible(button)) {
          return button;
        }
      }
    }
    return null;
  }
  function findStopButton() {
    const selectors = [
      "button[data-testid='stop-button']",
      "button[aria-label*='Stop generating' i]",
      "button[aria-label*='Stop streaming' i]",
      "button[aria-label*='\u505C\u6B62\u751F\u6210']",
      "button[aria-label*='\u505C\u6B62\u56DE\u590D']"
    ];
    for (const selector of selectors) {
      const buttons = Array.from(document.querySelectorAll(selector));
      for (const button of buttons) {
        if (button instanceof HTMLButtonElement && visible(button)) return button;
      }
    }
    return null;
  }
  function isResponseGenerating() {
    return Boolean(findStopButton());
  }
  function findFileInput() {
    const composerRoot = findComposer()?.closest("form");
    const inputs = Array.from(
      (composerRoot || document).querySelectorAll("input[type='file']")
    );
    for (const input of inputs) {
      if (!(input instanceof HTMLInputElement)) continue;
      const accept = input.accept.toLowerCase();
      if (!accept || accept.includes("image") || /\.(?:png|jpe?g|webp|gif|avif)/.test(accept)) {
        return input;
      }
    }
    return null;
  }
  function findAttachButton() {
    const selectors = [
      "button[data-testid='composer-plus-btn']",
      "button[aria-label*='Attach' i]",
      "button[aria-label*='Upload' i]",
      "button[aria-label*='\u6DFB\u52A0']",
      "button[aria-label*='\u4E0A\u4F20']"
    ];
    for (const selector of selectors) {
      const buttons = Array.from(document.querySelectorAll(selector));
      for (const button of buttons) {
        if (button instanceof HTMLButtonElement && visible(button)) return button;
      }
    }
    return null;
  }
  function conversationTurnNumber(element) {
    const section = element.closest("section[data-testid^='conversation-turn-']");
    const match = section?.getAttribute("data-testid")?.match(/conversation-turn-(\d+)/);
    return match ? Number(match[1]) : -1;
  }
  function latestConversationTurn() {
    return Math.max(
      -1,
      ...Array.from(
        document.querySelectorAll("section[data-testid^='conversation-turn-']")
      ).map((section) => {
        const match = section.getAttribute("data-testid")?.match(/conversation-turn-(\d+)/);
        return match ? Number(match[1]) : -1;
      })
    );
  }
  function isGeneratedImage(image) {
    const alt = image.getAttribute("alt") || "";
    return /^(?:已生成图片|generated image)\s*[:：]/i.test(alt) || Boolean(image.closest('[class*="imagegen-image"], [class*="imagegen"]'));
  }
  function generatedImageKey(image) {
    return image.currentSrc || image.src || "";
  }
  function generatedImageKeys() {
    return new Set(
      Array.from(document.querySelectorAll("img")).filter(
        (image) => image instanceof HTMLImageElement && isGeneratedImage(image)
      ).map(generatedImageKey).filter(Boolean)
    );
  }
  function newGeneratedImages(baselineTurn, baselineKeys) {
    const candidates = Array.from(document.querySelectorAll("img")).filter(
      (image) => {
        if (!(image instanceof HTMLImageElement)) return false;
        if (!isGeneratedImage(image)) return false;
        const key = generatedImageKey(image);
        if (!key || baselineKeys.has(key)) return false;
        const turn = conversationTurnNumber(image);
        if (baselineTurn >= 0 && turn >= 0 && turn <= baselineTurn) return false;
        return image.complete && image.naturalWidth >= 256 && image.naturalHeight >= 256;
      }
    );
    return uniqueByKey(candidates, generatedImageKey);
  }
  function generatedImageName(image, fallbackTitle) {
    const alt = (image.getAttribute("alt") || "").replace(
      /^(?:已生成图片|generated image)\s*[:：]\s*/i,
      ""
    );
    return alt || fallbackTitle || "ChatGPT \u751F\u6210\u7ED3\u679C";
  }
  function newAssistantTurns(baselineTurn) {
    return Array.from(
      document.querySelectorAll("section[data-testid^='conversation-turn-']")
    ).filter((section) => {
      const match = section.getAttribute("data-testid")?.match(/conversation-turn-(\d+)/);
      const turn = match ? Number(match[1]) : -1;
      if (turn >= baselineTurn + 2) return true;
      const heading = Array.from(section.querySelectorAll("h4, h5, h6")).map((element) => element.textContent || "").join(" ");
      return turn > baselineTurn && /ChatGPT|assistant|助手/i.test(heading);
    });
  }
  function hasImageGenerationPlaceholder(turns) {
    return turns.some(
      (turn) => Boolean(turn.querySelector('[class*="imagegen"]')) || Array.from(turn.querySelectorAll("img")).some(
        (image) => image instanceof HTMLImageElement && isGeneratedImage(image)
      )
    );
  }
  async function attachReferenceImages(images, signal) {
    if (!images.length) return;
    let input = findFileInput();
    if (!input) {
      findAttachButton()?.click();
      const startedAt = Date.now();
      while (!input && Date.now() - startedAt < 2400) {
        await wait(120);
        input = findFileInput();
      }
    }
    if (!input) {
      throw new Error("\u627E\u4E0D\u5230\u53C2\u8003\u56FE\u4E0A\u4F20\u5165\u53E3\uFF0C\u8BF7\u628A\u56FE\u7247\u76F4\u63A5\u7C98\u8D34\u5230 ChatGPT \u8F93\u5165\u6846");
    }
    const transfer = new DataTransfer();
    for (const image of images) {
      const response = await fetch(image.dataUrl, { signal });
      const blob = await response.blob();
      const extension = blob.type.split("/")[1]?.replace("jpeg", "jpg") || "png";
      transfer.items.add(
        new File([blob], image.name || `branchboard-reference.${extension}`, {
          type: blob.type || "image/png"
        })
      );
    }
    const filesSetter = Object.getOwnPropertyDescriptor(
      HTMLInputElement.prototype,
      "files"
    )?.set;
    if (filesSetter) filesSetter.call(input, transfer.files);
    else input.files = transfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    await wait(1100);
  }

  // src/content/automation.ts
  var TEXT_RESPONSE_GRACE_MS = 1e4;
  var GENERATION_TIMEOUT_MS = 36e4;
  var HEARTBEAT_MS = 15e3;
  var active = null;
  function assertActive(execution) {
    if (execution.cancelled || execution.controller.signal.aborted) {
      throw new DOMException("\u8FD0\u884C\u5DF2\u53D6\u6D88", "AbortError");
    }
  }
  async function waitForComposer(execution, timeout = 1e4) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeout) {
      assertActive(execution);
      const composer = findComposer();
      if (composer) return composer;
      await wait(180);
    }
    throw new Error("\u6CA1\u6709\u627E\u5230 ChatGPT \u8F93\u5165\u6846\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u540E\u91CD\u8BD5");
  }
  async function waitForSendButton(execution, timeout = 1e4) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeout) {
      assertActive(execution);
      const button = findSendButton();
      if (button) return button;
      await wait(160);
    }
    throw new Error("\u63D0\u793A\u8BCD\u5DF2\u586B\u5165\uFF0C\u4F46\u53D1\u9001\u6309\u94AE\u6682\u65F6\u4E0D\u53EF\u7528");
  }
  async function waitForSendStarted(execution, timeout = 1e4) {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeout) {
      assertActive(execution);
      if (findStopButton()) return;
      const composer = findComposer();
      if (composer && !composerText(composer)) return;
      await wait(150);
    }
    throw new Error("\u53D1\u9001\u6CA1\u6709\u5F00\u59CB\uFF0C\u8BF7\u68C0\u67E5 ChatGPT \u8F93\u5165\u6846");
  }
  async function storeGeneratedImage(request, image, signal, capturedFingerprints) {
    const imageUrl = image.currentSrc || image.src;
    if (!imageUrl) throw new Error("\u751F\u6210\u56FE\u7247\u6CA1\u6709\u53EF\u8BFB\u53D6\u7684\u5730\u5740");
    const response = await fetch(imageUrl, { credentials: "include", signal });
    if (!response.ok) throw new Error(`\u8BFB\u53D6\u751F\u6210\u56FE\u7247\u5931\u8D25 (${response.status})`);
    const blob = await response.blob();
    const hash = await sha256Hex(blob);
    if (capturedFingerprints.has(hash)) return false;
    capturedFingerprints.add(hash);
    const dataUrl = await blobToDataUrl(blob);
    const message = {
      type: MSG.storeImage,
      dataUrl,
      name: generatedImageName(image, request.title),
      canvasId: request.canvasId,
      promptId: request.promptId,
      requestId: request.requestId,
      relation: "generated",
      width: image.naturalWidth,
      height: image.naturalHeight,
      hash
    };
    const stored = await chrome.runtime.sendMessage(message);
    if (!stored?.ok) {
      throw new Error(stored?.error || "\u751F\u6210\u7ED3\u679C\u5199\u5165\u672C\u5730\u753B\u5E03\u5931\u8D25");
    }
    return true;
  }
  async function waitForGeneratedResults(request, execution, hooks, baselineTurn, baselineKeys) {
    const startedAt = Date.now();
    let firstReadyAt = 0;
    let textResponseReadyAt = 0;
    let lastHeartbeatAt = Date.now();
    hooks.report(request, "waiting", "ChatGPT \u6B63\u5728\u751F\u6210\u56FE\u7247");
    while (Date.now() - startedAt < GENERATION_TIMEOUT_MS) {
      assertActive(execution);
      if (Date.now() - lastHeartbeatAt >= HEARTBEAT_MS) {
        lastHeartbeatAt = Date.now();
        const elapsed = Math.round((Date.now() - startedAt) / 1e3);
        hooks.report(request, "waiting", `\u6B63\u5728\u7B49\u5F85 ChatGPT \u751F\u6210 \xB7 \u5DF2\u7B49\u5F85 ${elapsed} \u79D2`);
      }
      const candidates = newGeneratedImages(baselineTurn, baselineKeys);
      if (!candidates.length) {
        firstReadyAt = 0;
        const assistantTurns = newAssistantTurns(baselineTurn);
        const stillRunning = isResponseGenerating();
        const imagePlaceholder = hasImageGenerationPlaceholder(assistantTurns);
        if (assistantTurns.length && !stillRunning && !imagePlaceholder) {
          if (!textResponseReadyAt) textResponseReadyAt = Date.now();
          if (Date.now() - textResponseReadyAt >= TEXT_RESPONSE_GRACE_MS) {
            throw new Error("ChatGPT \u8FD4\u56DE\u4E86\u6587\u5B57\uFF0C\u6CA1\u6709\u751F\u6210\u56FE\u7247");
          }
        } else {
          textResponseReadyAt = 0;
        }
        await wait(900);
        continue;
      }
      textResponseReadyAt = 0;
      if (!firstReadyAt) firstReadyAt = Date.now();
      if (Date.now() - firstReadyAt < 1600) {
        await wait(400);
        continue;
      }
      hooks.report(request, "capturing", `\u6B63\u5728\u8BFB\u53D6 ${candidates.length} \u5F20\u56FE\u7247`);
      const capturedFingerprints = /* @__PURE__ */ new Set();
      let capturedCount = 0;
      for (const image of candidates) {
        assertActive(execution);
        if (await storeGeneratedImage(
          request,
          image,
          execution.controller.signal,
          capturedFingerprints
        )) {
          capturedCount += 1;
        }
      }
      hooks.report(
        request,
        "captured",
        capturedCount > 0 ? `${capturedCount} \u5F20\u56FE\u7247\u5DF2\u52A0\u5165\u753B\u5E03` : "\u751F\u6210\u56FE\u7247\u4E0E\u5DF2\u6709\u7ED3\u679C\u76F8\u540C\uFF0C\u672A\u91CD\u590D\u52A0\u5165"
      );
      return;
    }
    throw new Error("\u7B49\u5F85\u751F\u6210\u56FE\u7247\u8D85\u65F6\uFF0C\u8BF7\u68C0\u67E5 ChatGPT \u662F\u5426\u751F\u6210\u6210\u529F");
  }
  function cancelAutomation(requestIds, hooks) {
    if (!active || !requestIds.includes(active.request.requestId)) return;
    active.cancelled = true;
    active.controller.abort();
    findStopButton()?.click();
    hooks.report(active.request, "cancelled", "\u5DF2\u53D6\u6D88\u751F\u6210");
  }
  async function executePrompt(request, hooks) {
    if (active) {
      hooks.report(request, "failed", "\u53E6\u4E00\u4E2A\u8282\u70B9\u6B63\u5728\u6267\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      hooks.onError("\u53E6\u4E00\u4E2A\u8282\u70B9\u6B63\u5728\u6267\u884C\uFF0C\u8BF7\u7A0D\u540E\u91CD\u8BD5");
      return;
    }
    const execution = {
      request,
      cancelled: false,
      controller: new AbortController()
    };
    active = execution;
    hooks.onRunning();
    let outcome = "error";
    try {
      const prompt = String(request.prompt || "").trim();
      if (!prompt) throw new Error("\u63D0\u793A\u8BCD\u662F\u7A7A\u7684");
      const composer = await waitForComposer(execution);
      if (!composer) throw new Error("\u6CA1\u6709\u627E\u5230 ChatGPT \u8F93\u5165\u6846\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u540E\u91CD\u8BD5");
      if (composerText(composer)) {
        throw new Error("ChatGPT \u8F93\u5165\u6846\u91CC\u5DF2\u6709\u5185\u5BB9\uFF0C\u8BF7\u5148\u6E05\u7A7A\u6216\u53D1\u9001\u540E\u518D\u8BD5");
      }
      if (request.references?.length) {
        hooks.report(request, "attaching", `\u6B63\u5728\u9644\u52A0 ${request.references.length} \u5F20\u53C2\u8003\u56FE`);
        assertActive(execution);
        await attachReferenceImages(request.references, execution.controller.signal);
        assertActive(execution);
      }
      hooks.report(request, "filling", "\u6B63\u5728\u586B\u5165\u63D0\u793A\u8BCD");
      fillComposer(composer, prompt);
      await wait(200);
      assertActive(execution);
      if (!composerText(findComposer() ?? composer)) {
        throw new Error("\u672A\u80FD\u5199\u5165 ChatGPT \u8F93\u5165\u6846\uFF0C\u8BF7\u5237\u65B0\u9875\u9762\u540E\u91CD\u8BD5");
      }
      hooks.report(request, "sending", "\u6B63\u5728\u53D1\u9001");
      const sendButton = await waitForSendButton(execution);
      const baselineTurn = latestConversationTurn();
      const baselineKeys = generatedImageKeys();
      assertActive(execution);
      sendButton.click();
      await waitForSendStarted(execution);
      hooks.report(request, "sent", "\u5DF2\u53D1\u9001\uFF0C\u7B49\u5F85\u751F\u6210\u56FE\u7247");
      await waitForGeneratedResults(
        request,
        execution,
        hooks,
        baselineTurn,
        baselineKeys
      );
      outcome = "done";
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") {
        outcome = "cancelled";
      } else {
        const message = error instanceof Error ? error.message : String(error);
        outcome = "error";
        hooks.report(request, "failed", message);
        hooks.onError(message);
      }
    } finally {
      if (active === execution) active = null;
      hooks.onFinished(outcome);
    }
  }

  // src/shared/geometry.ts
  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }
  function pixelNumber(value, fallback) {
    const match = String(value ?? "").match(/^(-?\d+(?:\.\d+)?)px$/);
    return match ? Number(match[1]) : fallback;
  }
  function normalizeFloatingGeometry(geometry, viewport, options = {}) {
    const margin = Math.max(0, Number(options.margin ?? 8));
    const viewportWidth = Math.max(1, Number(viewport?.width || 0));
    const viewportHeight = Math.max(1, Number(viewport?.height || 0));
    const maxWidth = Math.max(1, viewportWidth - margin * 2);
    const maxHeight = Math.max(1, viewportHeight - margin * 2);
    const minWidth = Math.min(Math.max(1, Number(options.minWidth ?? 480)), maxWidth);
    const minHeight = Math.min(Math.max(1, Number(options.minHeight ?? 360)), maxHeight);
    const width = clamp(
      pixelNumber(geometry?.width, Math.min(Number(options.defaultWidth ?? 900), maxWidth)),
      minWidth,
      maxWidth
    );
    const height = clamp(
      pixelNumber(geometry?.height, Math.min(Number(options.defaultHeight ?? 700), maxHeight)),
      minHeight,
      maxHeight
    );
    const fallbackLeft = viewportWidth - width - 18;
    const fallbackTop = viewportHeight - height - 18;
    const right = pixelNumber(geometry?.right, Number.NaN);
    const bottom = pixelNumber(geometry?.bottom, Number.NaN);
    const left = clamp(
      pixelNumber(
        geometry?.left,
        Number.isFinite(right) ? viewportWidth - width - right : fallbackLeft
      ),
      margin,
      Math.max(margin, viewportWidth - width - margin)
    );
    const top = clamp(
      pixelNumber(
        geometry?.top,
        Number.isFinite(bottom) ? viewportHeight - height - bottom : fallbackTop
      ),
      margin,
      Math.max(margin, viewportHeight - height - margin)
    );
    return {
      left: Math.round(left),
      top: Math.round(top),
      width: Math.round(width),
      height: Math.round(height)
    };
  }

  // src/content/shell.ts
  var GEOMETRY_KEY = "floatingCanvasGeometry";
  var ORB_KEY = "floatingOrbPosition";
  function storageGet(key) {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      return chrome.storage.local.get(key).then((result) => {
        return result[key] ?? null;
      });
    }
    try {
      const stored = localStorage.getItem(key);
      return Promise.resolve(stored ? JSON.parse(stored) : null);
    } catch {
      return Promise.resolve(null);
    }
  }
  function storageSet(key, value) {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      return chrome.storage.local.set({ [key]: value });
    }
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
    }
    return Promise.resolve();
  }
  function createFloatingShell() {
    const host = document.createElement("div");
    host.id = "branchboard-floating-canvas-host";
    host.style.position = "fixed";
    host.style.inset = "0";
    host.style.zIndex = "2147483647";
    host.style.pointerEvents = "none";
    document.documentElement.appendChild(host);
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
    <style>
      :host {
        all: initial;
        color-scheme: dark;
        font-family: "Segoe UI Variable Text", "PingFang SC", "Microsoft YaHei UI",
          "Microsoft YaHei", "Segoe UI", Arial, sans-serif;
        --bb-canvas-bg: #101315;
        --bb-surface: #171b1f;
        --bb-surface-raised: #1d2227;
        --bb-surface-hover: #242a30;
        --bb-border: #2a3036;
        --bb-border-strong: #3a424a;
        --bb-text: #e8eaed;
        --bb-text-muted: #8d969f;
        --bb-text-faint: #646d76;
        --bb-accent: #df7c46;
        --bb-success: #69b18c;
        --bb-danger: #d87575;
        --bb-shadow: 0 18px 48px rgba(0,0,0,.42);
      }
      :host(.light) {
        color-scheme: light;
        --bb-canvas-bg: #f2f1ee;
        --bb-surface: #fbfaf8;
        --bb-surface-raised: #ffffff;
        --bb-surface-hover: #f0ece7;
        --bb-border: #ddd9d2;
        --bb-border-strong: #c7c1b8;
        --bb-text: #252b31;
        --bb-text-muted: #6d757d;
        --bb-text-faint: #979ea5;
        --bb-accent: #c65f2f;
        --bb-success: #42805e;
        --bb-danger: #b25353;
        --bb-shadow: 0 18px 48px rgba(60,52,44,.24);
      }
      * { box-sizing: border-box; }
      button { font: inherit; }

      .orb {
        position: fixed;
        right: 18px;
        bottom: 18px;
        display: grid;
        width: 48px;
        height: 48px;
        place-items: center;
        padding: 0;
        border: 1px solid var(--bb-border-strong);
        border-radius: 10px;
        color: var(--bb-text-muted);
        background: var(--bb-surface);
        box-shadow: 0 10px 28px rgba(0,0,0,.32);
        cursor: grab;
        pointer-events: auto;
        touch-action: none;
        transition: transform .14s ease, background .14s ease;
      }
      .orb:hover { color: var(--bb-text); background: var(--bb-surface-hover); transform: translateY(-1px); }
      .orb:active, .orb.dragging { cursor: grabbing; transform: scale(.97); }
      .orb.hidden { display: none; }
      .orb svg { width: 28px; height: 28px; overflow: visible; }
      .orb .frame { fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; opacity: .55; }
      .orb .link { fill: none; stroke: var(--bb-accent); stroke-width: 1.7; stroke-linecap: round; stroke-linejoin: round; }
      .orb .node { fill: var(--bb-surface-raised); stroke: var(--bb-text-muted); stroke-width: .7; }
      .orb-status {
        position: absolute;
        top: -2px;
        right: -2px;
        width: 10px;
        height: 10px;
        border: 2px solid var(--bb-surface);
        border-radius: 50%;
        background: transparent;
        opacity: 0;
        transform: scale(.5);
        transition: opacity .15s ease, transform .15s ease;
      }
      .orb-status.running { opacity: 1; transform: scale(1); background: var(--bb-accent); animation: pulse 1.3s ease-in-out infinite; }
      .orb-status.done { opacity: 1; transform: scale(1); background: var(--bb-success); }
      .orb-status.error { opacity: 1; transform: scale(1); background: var(--bb-danger); }
      @keyframes pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(223,124,70,.42); } 50% { box-shadow: 0 0 0 6px rgba(223,124,70,0); } }

      .floating {
        position: fixed;
        z-index: 2;
        display: none;
        overflow: hidden;
        border: 1px solid var(--bb-border-strong);
        border-radius: 10px;
        background: var(--bb-canvas-bg);
        box-shadow: var(--bb-shadow);
        pointer-events: auto;
      }
      .floating.open { display: block; }

      .shell-header {
        position: relative;
        z-index: 2;
        display: flex;
        height: 36px;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 0 6px 0 10px;
        border-bottom: 1px solid var(--bb-border);
        background: var(--bb-surface);
        cursor: grab;
        user-select: none;
      }
      .shell-header:active { cursor: grabbing; }
      .shell-brand { display: flex; align-items: center; gap: 7px; color: var(--bb-text); font-size: 11.5px; font-weight: 600; letter-spacing: .01em; }
      .shell-brand svg { width: 19px; height: 19px; overflow: visible; }
      .shell-brand .frame { fill: none; stroke: var(--bb-text-muted); stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; opacity: .55; }
      .shell-brand .link { fill: none; stroke: var(--bb-accent); stroke-width: 1.7; stroke-linecap: round; stroke-linejoin: round; }
      .shell-brand .node { fill: var(--bb-surface-raised); stroke: var(--bb-text-muted); stroke-width: .7; }
      .shell-actions { display: flex; gap: 1px; }
      .shell-button {
        display: grid;
        width: 28px;
        height: 26px;
        place-items: center;
        border-radius: 4px;
        color: var(--bb-text-muted);
        background: transparent;
      }
      .shell-button:hover { color: var(--bb-text); background: var(--bb-surface-hover); }
      .shell-button svg { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 1.5; stroke-linecap: round; stroke-linejoin: round; }

      .canvas-frame {
        display: block;
        width: 100%;
        height: calc(100% - 36px);
        border: 0;
        background: var(--bb-canvas-bg);
      }

      .resize-handle {
        position: absolute;
        z-index: 3;
        right: 0;
        bottom: 0;
        width: 20px;
        height: 20px;
        border: 0;
        background:
          linear-gradient(135deg, transparent 48%, rgba(135,148,161,.25) 49%, rgba(135,148,161,.25) 54%, transparent 55%),
          linear-gradient(135deg, transparent 66%, rgba(135,148,161,.32) 67%, rgba(135,148,161,.32) 72%, transparent 73%);
        cursor: nwse-resize;
      }
      .resize-handle:hover {
        background:
          linear-gradient(135deg, transparent 48%, var(--bb-accent) 49%, var(--bb-accent) 54%, transparent 55%),
          linear-gradient(135deg, transparent 66%, var(--bb-accent) 67%, var(--bb-accent) 72%, transparent 73%);
      }
      .resize-handle.hidden { display: none; }

      .toast {
        position: fixed;
        z-index: 6;
        right: 18px;
        bottom: 78px;
        display: flex;
        max-width: min(320px, calc(100vw - 36px));
        align-items: center;
        gap: 7px;
        padding: 8px 10px;
        border: 1px solid var(--bb-border-strong);
        border-radius: 7px;
        color: var(--bb-text);
        background: var(--bb-surface-raised);
        box-shadow: var(--bb-shadow);
        font-size: 10.5px;
        line-height: 1.4;
        pointer-events: none;
        opacity: 0;
        transform: translateY(5px);
        transition: opacity .16s ease, transform .16s ease;
      }
      .toast.show { opacity: 1; transform: translateY(0); }
      .toast-mark {
        display: grid;
        width: 17px;
        height: 17px;
        flex: none;
        place-items: center;
        border-radius: 50%;
        color: var(--bb-success);
        background: rgba(105,177,140,.13);
        font-size: 10px;
        font-weight: 700;
      }
      .toast.warn { border-color: var(--bb-danger); }
      .toast.warn .toast-mark { color: var(--bb-danger); background: rgba(216,117,117,.13); }

      @media (max-width: 640px) {
        .floating {
          left: 8px !important;
          top: 8px !important;
          width: calc(100vw - 16px) !important;
          height: calc(100vh - 16px) !important;
        }
      }
    </style>
    <button class="orb" type="button" title="\u6253\u5F00 Branchboard \u753B\u5E03" aria-label="Branchboard \u753B\u5E03">
      <svg viewBox="0 0 32 32" aria-hidden="true">
        <path class="frame" d="M7.5 12V7.5H12M20 7.5h4.5V12M24.5 20v4.5H20M12 24.5H7.5V20"/>
        <path class="link" d="m10.5 11.5 5 4.5 6-5M15.5 16v5"/>
        <circle class="node" cx="10.5" cy="11.5" r="2.35"/>
        <circle class="node" cx="21.5" cy="11" r="2.35"/>
        <circle class="node" cx="15.5" cy="21" r="2.35"/>
      </svg>
      <span class="orb-status"></span>
    </button>
    <section class="floating" aria-label="Branchboard \u6D6E\u52A8\u753B\u5E03">
      <header class="shell-header">
        <div class="shell-brand">
          <svg viewBox="0 0 32 32" aria-hidden="true">
            <path class="frame" d="M7.5 12V7.5H12M20 7.5h4.5V12M24.5 20v4.5H20M12 24.5H7.5V20"/>
            <path class="link" d="m10.5 11.5 5 4.5 6-5M15.5 16v5"/>
            <circle class="node" cx="10.5" cy="11.5" r="2.35"/>
            <circle class="node" cx="21.5" cy="11" r="2.35"/>
            <circle class="node" cx="15.5" cy="21" r="2.35"/>
          </svg>
          <span>Branchboard</span>
        </div>
        <div class="shell-actions">
          <button class="shell-button maximize" type="button" title="\u6700\u5927\u5316" aria-label="\u6700\u5927\u5316">
            <svg viewBox="0 0 20 20"><rect x="4.5" y="4.5" width="11" height="11" rx="1"/></svg>
          </button>
          <button class="shell-button minimize" type="button" title="\u6536\u8D77\u753B\u5E03" aria-label="\u6536\u8D77\u753B\u5E03">
            <svg viewBox="0 0 20 20"><path d="M4.5 10h11"/></svg>
          </button>
        </div>
      </header>
      <iframe class="canvas-frame" title="Branchboard \u753B\u5E03"></iframe>
      <button class="resize-handle" type="button" title="\u62D6\u52A8\u8C03\u6574\u753B\u5E03\u5927\u5C0F" aria-label="\u62D6\u52A8\u8C03\u6574\u753B\u5E03\u5927\u5C0F"></button>
    </section>
    <div class="toast" role="status" aria-live="polite"><i class="toast-mark">\u2713</i><span class="toast-text"></span></div>
  `;
    const orb = root.querySelector(".orb");
    const statusDot = root.querySelector(".orb-status");
    const floating = root.querySelector(".floating");
    const header = root.querySelector(".shell-header");
    const minimize = root.querySelector(".minimize");
    const maximize = root.querySelector(".maximize");
    const frame = root.querySelector(".canvas-frame");
    const resizeHandle = root.querySelector(".resize-handle");
    const toast = root.querySelector(".toast");
    const toastMark = root.querySelector(".toast-mark");
    const toastText = root.querySelector(".toast-text");
    frame.src = `${chrome.runtime.getURL("canvas.html")}?embedded=1`;
    let open = false;
    let maximized = false;
    let savedGeometry = null;
    let floatingGeometry = null;
    let orbPosition = null;
    let toastTimer = 0;
    let activityTimer = 0;
    let dragState = null;
    let orbDrag = null;
    let resizeState = null;
    let suppressOrbClickUntil = 0;
    function showToast(message, warning = false) {
      if (!message) return;
      window.clearTimeout(toastTimer);
      toastText.textContent = message;
      toastMark.textContent = warning ? "!" : "\u2713";
      toast.classList.toggle("warn", warning);
      toast.classList.add("show");
      toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3400);
    }
    function setActivity(state) {
      window.clearTimeout(activityTimer);
      statusDot.className = "orb-status";
      if (state !== "idle") statusDot.classList.add(state);
      if (state === "done") {
        activityTimer = window.setTimeout(() => setActivity("idle"), 4200);
      }
    }
    function applyTheme(theme) {
      host.classList.toggle("light", theme === "light");
    }
    function applyOrbPosition() {
      orb.style.left = "";
      orb.style.top = "";
      orb.style.right = "18px";
      orb.style.bottom = "18px";
      if (!orbPosition) return;
      const maxLeft = Math.max(6, window.innerWidth - 54);
      const maxTop = Math.max(6, window.innerHeight - 54);
      orb.style.left = `${Math.min(maxLeft, Math.max(6, orbPosition.left))}px`;
      orb.style.top = `${Math.min(maxTop, Math.max(6, orbPosition.top))}px`;
      orb.style.right = "auto";
      orb.style.bottom = "auto";
    }
    function readGeometry() {
      const rect = floating.getBoundingClientRect();
      return {
        left: `${Math.round(rect.left)}px`,
        top: `${Math.round(rect.top)}px`,
        width: `${Math.round(rect.width)}px`,
        height: `${Math.round(rect.height)}px`
      };
    }
    function applyGeometry() {
      const normalized = normalizeFloatingGeometry(
        floatingGeometry,
        { width: window.innerWidth, height: window.innerHeight },
        {
          minWidth: 520,
          minHeight: 420,
          defaultWidth: 900,
          defaultHeight: 700,
          margin: 8
        }
      );
      floatingGeometry = {
        left: `${normalized.left}px`,
        top: `${normalized.top}px`,
        width: `${normalized.width}px`,
        height: `${normalized.height}px`
      };
      floating.style.left = floatingGeometry.left;
      floating.style.top = floatingGeometry.top;
      floating.style.width = floatingGeometry.width;
      floating.style.height = floatingGeometry.height;
    }
    function persistGeometry() {
      if (maximized) return;
      floatingGeometry = readGeometry();
      void storageSet(GEOMETRY_KEY, floatingGeometry);
    }
    function persistOrbPosition() {
      const rect = orb.getBoundingClientRect();
      orbPosition = { left: Math.round(rect.left), top: Math.round(rect.top) };
      void storageSet(ORB_KEY, orbPosition);
    }
    function setMaximized(next) {
      if (next === maximized) return;
      maximized = next;
      if (maximized) {
        savedGeometry = readGeometry();
        floating.style.left = "8px";
        floating.style.top = "8px";
        floating.style.width = "calc(100vw - 16px)";
        floating.style.height = "calc(100vh - 16px)";
        resizeHandle.classList.add("hidden");
        maximize.title = "\u8FD8\u539F";
        maximize.setAttribute("aria-label", "\u8FD8\u539F\u7A97\u53E3");
        maximize.innerHTML = '<svg viewBox="0 0 20 20"><rect x="6" y="6" width="9" height="9" rx="1"/><path d="M4.5 12V4.5H12"/></svg>';
      } else {
        floatingGeometry = savedGeometry ?? floatingGeometry;
        applyGeometry();
        resizeHandle.classList.remove("hidden");
        maximize.title = "\u6700\u5927\u5316";
        maximize.setAttribute("aria-label", "\u6700\u5927\u5316");
        maximize.innerHTML = '<svg viewBox="0 0 20 20"><rect x="4.5" y="4.5" width="11" height="11" rx="1"/></svg>';
      }
    }
    function setOpen(next) {
      if (next === open) return;
      if (next) {
        applyGeometry();
      } else {
        if (maximized) setMaximized(false);
        applyOrbPosition();
      }
      open = next;
      orb.classList.toggle("hidden", open);
      floating.classList.toggle("open", open);
      if (open) setActivity("idle");
    }
    orb.addEventListener("click", () => {
      if (Date.now() < suppressOrbClickUntil) return;
      setOpen(true);
    });
    orb.addEventListener("pointerdown", (event) => {
      if (event.button !== 0) return;
      const rect = orb.getBoundingClientRect();
      orbDrag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top,
        moved: false
      };
    });
    window.addEventListener(
      "pointermove",
      (event) => {
        if (!orbDrag || orbDrag.pointerId !== event.pointerId) return;
        if (Math.hypot(
          event.clientX - orbDrag.startX,
          event.clientY - orbDrag.startY
        ) >= 4) {
          orbDrag.moved = true;
          orb.classList.add("dragging");
        }
        if (!orbDrag.moved) return;
        const maxLeft = Math.max(6, window.innerWidth - 54);
        const maxTop = Math.max(6, window.innerHeight - 54);
        orb.style.left = `${Math.min(maxLeft, Math.max(6, event.clientX - orbDrag.offsetX))}px`;
        orb.style.top = `${Math.min(maxTop, Math.max(6, event.clientY - orbDrag.offsetY))}px`;
        orb.style.right = "auto";
        orb.style.bottom = "auto";
      },
      true
    );
    window.addEventListener(
      "pointerup",
      (event) => {
        if (!orbDrag || orbDrag.pointerId !== event.pointerId) return;
        const moved = orbDrag.moved;
        orbDrag = null;
        orb.classList.remove("dragging");
        if (moved) {
          suppressOrbClickUntil = Date.now() + 250;
          persistOrbPosition();
        }
      },
      true
    );
    window.addEventListener("pointercancel", () => {
      orbDrag = null;
      orb.classList.remove("dragging");
      applyOrbPosition();
    });
    header.addEventListener("pointerdown", (event) => {
      if (maximized || event.target instanceof Element && event.target.closest("button")) {
        return;
      }
      const rect = floating.getBoundingClientRect();
      dragState = {
        pointerId: event.pointerId,
        offsetX: event.clientX - rect.left,
        offsetY: event.clientY - rect.top
      };
      header.setPointerCapture(event.pointerId);
    });
    header.addEventListener("pointermove", (event) => {
      if (!dragState || dragState.pointerId !== event.pointerId) return;
      const maxLeft = Math.max(6, window.innerWidth - floating.offsetWidth - 6);
      const maxTop = Math.max(6, window.innerHeight - floating.offsetHeight - 6);
      floating.style.left = `${Math.min(maxLeft, Math.max(6, event.clientX - dragState.offsetX))}px`;
      floating.style.top = `${Math.min(maxTop, Math.max(6, event.clientY - dragState.offsetY))}px`;
    });
    header.addEventListener("pointerup", (event) => {
      if (dragState?.pointerId !== event.pointerId) return;
      header.releasePointerCapture(event.pointerId);
      dragState = null;
      persistGeometry();
    });
    header.addEventListener("dblclick", (event) => {
      if (event.target instanceof Element && event.target.closest("button")) return;
      setMaximized(!maximized);
    });
    resizeHandle.addEventListener("pointerdown", (event) => {
      if (maximized) return;
      event.preventDefault();
      event.stopPropagation();
      const rect = floating.getBoundingClientRect();
      resizeState = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        left: rect.left,
        top: rect.top,
        width: rect.width,
        height: rect.height
      };
      resizeHandle.setPointerCapture(event.pointerId);
    });
    resizeHandle.addEventListener("pointermove", (event) => {
      if (!resizeState || resizeState.pointerId !== event.pointerId) return;
      const minWidth = Math.min(520, window.innerWidth - 16);
      const minHeight = Math.min(420, window.innerHeight - 16);
      const maxWidth = Math.max(minWidth, window.innerWidth - resizeState.left - 8);
      const maxHeight = Math.max(minHeight, window.innerHeight - resizeState.top - 8);
      const width = Math.min(
        maxWidth,
        Math.max(minWidth, resizeState.width + event.clientX - resizeState.startX)
      );
      const height = Math.min(
        maxHeight,
        Math.max(minHeight, resizeState.height + event.clientY - resizeState.startY)
      );
      floating.style.width = `${width}px`;
      floating.style.height = `${height}px`;
    });
    resizeHandle.addEventListener("pointerup", (event) => {
      if (resizeState?.pointerId !== event.pointerId) return;
      resizeHandle.releasePointerCapture(event.pointerId);
      resizeState = null;
      persistGeometry();
    });
    minimize.addEventListener("click", () => setOpen(false));
    maximize.addEventListener("click", () => setMaximized(!maximized));
    let resizeTimer = 0;
    window.addEventListener("resize", () => {
      if (maximized) return;
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(() => {
        if (open) {
          floatingGeometry = readGeometry();
          applyGeometry();
          persistGeometry();
        } else {
          applyOrbPosition();
          persistOrbPosition();
        }
      }, 80);
    });
    void (async () => {
      const [storedGeometry, storedOrb] = await Promise.all([
        storageGet(GEOMETRY_KEY),
        storageGet(ORB_KEY)
      ]);
      floatingGeometry = storedGeometry;
      orbPosition = storedOrb;
      if (open) applyGeometry();
      else applyOrbPosition();
    })();
    applyOrbPosition();
    return {
      frame,
      isOpen: () => open,
      setOpen,
      showToast,
      setActivity,
      applyTheme
    };
  }

  // src/content/main.ts
  (() => {
    const globalState = globalThis;
    if (globalState.__branchboardV2Loaded) return;
    globalState.__branchboardV2Loaded = true;
    document.getElementById("branchboard-floating-canvas-host")?.remove();
    const shell = createFloatingShell();
    async function applyStoredTheme() {
      shell.applyTheme(await readShellTheme());
    }
    void applyStoredTheme();
    listenSettings((settings) => shell.applyTheme(settings.theme));
    const hooks = {
      report(request, stage, message) {
        shell.frame.contentWindow?.postMessage(
          {
            type: MSG.progress,
            requestId: request.requestId,
            canvasId: request.canvasId,
            promptId: request.promptId,
            stage,
            message
          },
          "*"
        );
      },
      onRunning() {
        shell.setActivity("running");
      },
      onFinished(outcome) {
        if (outcome === "done") shell.setActivity("done");
        else if (outcome === "error") shell.setActivity("error");
        else {
          shell.setActivity("idle");
          if (!shell.isOpen()) shell.showToast("\u5DF2\u53D6\u6D88\u751F\u6210");
        }
      },
      onError(message) {
        if (!shell.isOpen()) shell.showToast(message, true);
      }
    };
    async function fileToDataUrl(file) {
      return blobToDataUrl(file);
    }
    async function importImageUrl(message) {
      const imageUrl = String(message.imageUrl || "");
      if (!imageUrl) throw new Error("\u62D6\u5165\u7684\u5185\u5BB9\u6CA1\u6709\u56FE\u7247\u5730\u5740");
      const response = await fetch(imageUrl, { credentials: "include" });
      if (!response.ok) throw new Error("\u56FE\u7247\u8BFB\u53D6\u53D7\u9650\uFF0C\u8BF7\u590D\u5236\u56FE\u7247\u540E\u5728\u753B\u5E03\u4E2D\u7C98\u8D34");
      const blob = await response.blob();
      if (!blob.type.startsWith("image/")) throw new Error("\u62D6\u5165\u7684\u5185\u5BB9\u4E0D\u662F\u56FE\u7247");
      let size = { width: 1024, height: 1024 };
      try {
        size = await imageSizeFromBlob(blob);
      } catch {
      }
      const dataUrl = await blobToDataUrl(blob);
      const hash = await sha256Hex(blob);
      const storeMessage = {
        type: MSG.storeImage,
        dataUrl,
        name: "\u62D6\u5165\u56FE\u7247",
        canvasId: String(message.canvasId || ""),
        promptId: message.promptId ? String(message.promptId) : void 0,
        requestId: `import-${crypto.randomUUID()}`,
        relation: message.promptId ? "reference" : void 0,
        position: message.position,
        width: size.width,
        height: size.height,
        hash
      };
      const stored = await chrome.runtime.sendMessage(storeMessage);
      if (!stored?.ok) throw new Error(stored?.error || "\u56FE\u7247\u5199\u5165\u753B\u5E03\u5931\u8D25");
    }
    window.addEventListener("message", (event) => {
      if (event.source !== shell.frame.contentWindow) return;
      const data = event.data;
      if (!data || typeof data.type !== "string") return;
      if (data.type === MSG.runPrompt) {
        const request = data;
        void executePrompt(
          {
            requestId: request.requestId,
            canvasId: request.canvasId,
            promptId: request.promptId,
            title: request.title,
            prompt: request.prompt,
            references: Array.isArray(request.references) ? request.references : []
          },
          hooks
        );
        return;
      }
      if (data.type === MSG.cancelRun) {
        const message = data;
        cancelAutomation(
          Array.isArray(message.requestIds) ? message.requestIds.map(String) : [],
          hooks
        );
        return;
      }
      if (data.type === MSG.importUrl) {
        void importImageUrl(data).catch((error) => {
          shell.showToast(
            error instanceof Error ? error.message : "\u56FE\u7247\u8BFB\u53D6\u5931\u8D25",
            true
          );
        });
        return;
      }
      if (data.type === MSG.theme) {
        shell.applyTheme(data.theme);
        return;
      }
      if (data.type === MSG.minimize) {
        shell.setOpen(false);
        return;
      }
      if (data.type === MSG.resultNotice) {
        const message = data;
        if (!shell.isOpen() && message.count > 0) {
          shell.setActivity("done");
          shell.showToast(`${message.count} \u5F20\u56FE\u7247\u5DF2\u52A0\u5165\u753B\u5E03`);
        }
      }
    });
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type === MSG.toggleCanvas) {
        shell.setOpen(!shell.isOpen());
      }
    });
    window.addEventListener(
      "paste",
      (event) => {
        if (!shell.isOpen()) return;
        const items = event.clipboardData?.items;
        if (!items) return;
        const imageItem = Array.from(items).find(
          (item) => item.kind === "file" && item.type.startsWith("image/")
        );
        if (!imageItem) return;
        const target = event.target instanceof Element ? event.target : null;
        if (target?.closest("textarea, input, [contenteditable='true'], form")) {
          return;
        }
        const file = imageItem.getAsFile();
        if (!file) return;
        event.preventDefault();
        event.stopPropagation();
        void fileToDataUrl(file).then((dataUrl) => {
          shell.frame.contentWindow?.postMessage(
            {
              type: MSG.forwardPaste,
              dataUrl,
              name: file.name || "\u7C98\u8D34\u56FE\u7247"
            },
            "*"
          );
        }).catch(() => shell.showToast("\u7C98\u8D34\u56FE\u7247\u5931\u8D25", true));
      },
      true
    );
  })();
})();
